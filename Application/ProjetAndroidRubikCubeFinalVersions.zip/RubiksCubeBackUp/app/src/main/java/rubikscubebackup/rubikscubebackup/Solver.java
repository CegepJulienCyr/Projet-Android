package rubikscubebackup.rubikscubebackup;

import java.util.ArrayList;

class Solver {
    private ArrayList<FaceDuCube> cube;
    public Solver(ArrayList<FaceDuCube> cubes){
        cube = cubes;
    }


    private String resoudreCroix(){

        return "";
    }

    private String resoudreCouronne(){
        return "";
    }


    private String  resoudreCroixJaune(){
        return "";
    }

    private String resoudreCentreJaune(){
        return "";
    }

    private String resoudreCoinFaceJaune(){
        return "";
    }


    private String resoudreCoins(){
        return "";
    }

    private String resoudreDerniereEtape(){
        return "";
    }

    private boolean VerifResolu(){
        return false;
    }


    private boolean VerifNombreCouleur(){

        int nbrW = 0;
        int nbrJ = 0;
        int nbrB = 0;
        int nbrR = 0;
        int nbrV = 0;
        int nbrO = 0;
        for (FaceDuCube face: cube)
        {
            for(int nbr = 0;nbr < face.getCarre().length; nbr++){
                {
                    switch (face.getCarre()[nbr]){
                        case 0:
                            nbrW++;
                        case 1:

                    }
                }
            }
        }
        return false;
    }

    private boolean VerifCroix(){
        return false;
    }


    private boolean VerifCouronne(){
        return false;
    }


    private boolean VerifacBlanch(){
        return false;
    }

    private boolean VerifCroixJauneComplet(){
        return false;
    }

    private boolean VerifCoinsJaune(){
        return false;
    }

    public int AnalyserCube(){

        int etat = 0;

        if(VerifCroix() == false){
            etat = 1;
        }
        if(VerifCouronne() == false){
            etat = 2;
        }
        if(VerifCroixJauneComplet() == false){
            etat = 3;
        }
        if(VerifCoinsJaune() == false){
            etat = 4;
        }
        return etat;
    }

    public String SolveCube(){
        String solution;
        if(VerifNombreCouleur() == true && VerifResolu() == false){
            solution= ResoudreCube(AnalyserCube());
            return solution;
        }
        else if(VerifNombreCouleur() == false){
            return "Le cube est imposible a résoudre";
        }
        else{
            return "Le cube est déja résolue";
        }


    }

    public String ResoudreCube(int etat){
        String solution = "";
        switch (etat){
            case 1:
                solution += resoudreCroix();
                solution += resoudreCoins();
                solution += resoudreCouronne();
                solution += resoudreCroixJaune();
                solution += resoudreCoinFaceJaune();
                solution += resoudreDerniereEtape();
            case 2:
                solution += resoudreCoins();
                solution += resoudreCouronne();
                solution += resoudreCroixJaune();
                solution += resoudreCoinFaceJaune();
                solution += resoudreDerniereEtape();
            case 3:
                solution += resoudreCroixJaune();
                solution += resoudreCoinFaceJaune();
                solution += resoudreDerniereEtape();
            case 4:
                solution += resoudreCoinFaceJaune();
                solution += resoudreDerniereEtape();
        }
        return solution;
    }
}
