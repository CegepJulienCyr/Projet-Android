package rubikscubebackup.rubikscubebackup;

class FaceDuCube {
    /*
    Code de Couleurs pour le Cube
      Blue  2
      White 0
      Yellow	1
      Green	4
      Orange	5
      Red 3
   */
    private int Centre = 0;

    public int[] getCarre() {
        return carre;
    }

    public void setCarre(int[] carre) {
        this.carre = carre;
    }

    private int carre[] = new int[8];


    public FaceDuCube(int tabCouleur[]){
        Centre = tabCouleur[0];
        for(int cpt = 0; cpt < 6;cpt++){
            carre[cpt] = tabCouleur[cpt];
        }
    }
}
