package rubikscubebackup.rubikscubebackup;

import android.Manifest;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.hardware.Camera;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    private static final int REQUEST_CAMERA = 100;
    public Button btnCamera;
    public Button btnAnalyser;
    FrameLayout mFrameLayout;
    ImageView imageCarre;
    ImageButton imgBtn1;
    ImageButton imgBtn2;
    ImageButton imgBtn3;
    ImageButton imgBtn4;
    ImageButton imgBtn5;
    ImageButton imgBtn6;
    ArrayList<Bitmap> listeimage = new ArrayList<Bitmap>();
    ArrayList<FaceDuCube> cubes;
    Solver solver;
    String solution;

    Bitmap image;
    Camera  mCamera;
    ShowCamera showCamera;
    public static final String ALLOW_KEY = "ALLOWED";
    public static final String CAMERA_PREF = "camera_pref";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mFrameLayout = (FrameLayout)findViewById(R.id.imgCamera);
        imgBtn1 = (ImageButton) findViewById(R.id.Face1);
        imgBtn2 = (ImageButton)findViewById(R.id.Face2);
        imgBtn3 = (ImageButton)findViewById(R.id.Face3);
        imgBtn4 = (ImageButton)findViewById(R.id.Face4);
        imgBtn5 = (ImageButton)findViewById(R.id.Face5);
        imgBtn6 = (ImageButton)findViewById(R.id.Face6);
        final TextView text = (TextView)findViewById(R.id.txtHeader);
        btnCamera = (Button)findViewById(R.id.btnAvtiver);
        btnAnalyser = (Button) findViewById(R.id.btnAnalyser);
        imageCarre = (ImageView)findViewById(R.id.imgCarre);
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.CAMERA},
                REQUEST_CAMERA);


        if (getFromPref(this, ALLOW_KEY)) {

            showSettingsAlert();

        } else if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.CAMERA)) {
                showAlert();
            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.CAMERA},
                        REQUEST_CAMERA);
            }

        }


        mCamera = Camera.open();
        showCamera = new ShowCamera(this,mCamera);
        mFrameLayout.addView(showCamera);
        btnCamera.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                mCamera.takePicture(null, null, mPictureCallBack);
            }
        });
    }
    Camera.PictureCallback mPictureCallBack = new android.hardware.Camera.PictureCallback() {
        public void onPictureTaken(byte[] imageData, Camera c) {

            Bitmap bitmap = BitmapFactory.decodeByteArray(imageData , 0, imageData .length);
            image = bitmap;
            Toast.makeText(getApplicationContext(),"Image a été Prise ",Toast.LENGTH_LONG).show();
        }
    };


    public void ChercherCouleur(Bitmap image){
        int pixel = image.getPixel(image.getHeight()/2,image.getWidth()/2);
        int pixelRouge = Color.red(pixel);
        int pixelBleu = Color.blue(pixel);
        int pixelVert = Color.green(pixel);
        TextView txtRouge = (TextView)findViewById(R.id.txtRouge);
        TextView txtBleu = (TextView)findViewById(R.id.txtBleu);
        TextView txtVert = (TextView)findViewById(R.id.txtVert);
        txtRouge.setText((CharSequence)txtRouge.getText().subSequence(0,14));
        txtBleu.setText((CharSequence)txtBleu.getText().subSequence(0,12));
        txtVert.setText((CharSequence)txtVert.getText().subSequence(0,12));
        txtRouge.setText(((CharSequence)txtRouge.getText() + String.valueOf(pixelRouge)));
        txtBleu.setText(((CharSequence)txtBleu.getText() + String.valueOf(pixelBleu)));
        txtVert.setText(((CharSequence)txtVert.getText() + String.valueOf(pixelVert)));
    }


    //private int getMax(int value, int delta){ return  value + delta; }

    // private int getMin(int value,int delta){ return  value - delta; }




    public int getColor(int R,int G, int B){

        Boolean Retour = true;
        if((R >240 && R <= 255) && (G >=0 && G<20) && (B >=0 && B<20)){
            return 2;
        }
        if((R >=0 && R <= 20) && (G >=14 && G<=54) && (B >=240 && B<=255)){
            return 3;
        }
        if((R >=240 && R <= 255) && (G >=240 && G<=255) && (B >=240 && B<=255)){
            return 0;
        }
        if((R >=230 && R <= 250) && (G >=210 && G<=255) && (B >=0 && B<=30)){
            return 1;
        }
        if((R >=180 && R <= 145) && (G >=145 && G<=185) && (B >=0 && B<=20)){
            return 5;
        }
        if((R >=0 && R <=20) && (G >=118 && G<=148) && (B >=20 && B<=60)){
            return 4;
        }
        return 00;
    }

    public ArrayList<FaceDuCube> CalculerCouleur(ArrayList<Bitmap> image) {
      /*  Blue            rgb: (0,34,255)
        White	#FFFFFF	rgb: (255,255,255)/(174,161,142)
        Yellow	#FFFF00	rgb: (230,240,10)
        Green	#008000	rgb: (0,128,40)
        Orange	#FFA500	rgb: (200,165,0)
        Red	#FF0000	rgb: (255,0,0)
      */
        int Delta = 20;
        ArrayList<FaceDuCube> listFaceCube = new ArrayList<FaceDuCube>();
        for (Bitmap imagebit : image) {
            int pixel;
            int pixelRouge;
            int pixelBleu;
            int pixelVert;
            int[] tabCouleur = new int[9];
            for(int pos = 0;pos < 9; pos++) {
                switch (pos){
                    case 0:
                        pixel = imagebit.getPixel(imagebit.getWidth()/2 - imageCarre.getWidth() / 2,imagebit.getHeight()/2 - imageCarre.getHeight() / 2);
                        pixelRouge = Color.red(pixel);
                        pixelBleu = Color.blue(pixel);
                        pixelVert = Color.green(pixel);
                        tabCouleur[0] = getColor(pixelRouge, pixelVert, pixelBleu);
                        break;
                    case 1:
                        pixel = imagebit.getPixel(imagebit.getWidth()/2 -imageCarre.getWidth() / 4,imagebit.getHeight()/2  -  imageCarre.getHeight() / 4);
                        pixelRouge = Color.red(pixel);
                        pixelBleu = Color.blue(pixel);
                        pixelVert = Color.green(pixel);
                        tabCouleur[pos] = getColor(pixelRouge, pixelVert, pixelBleu);
                        break;
                    case 2:
                        pixel = imagebit.getPixel(imagebit.getWidth()/2 - imageCarre.getWidth() / 2,imagebit.getHeight()/2  - imageCarre.getHeight() / 4);
                        pixelRouge = Color.red(pixel);
                        pixelBleu = Color.blue(pixel);
                        pixelVert = Color.green(pixel);
                        tabCouleur[pos] = getColor(pixelRouge, pixelVert, pixelBleu);
                        break;
                    case 3:
                        pixel = imagebit.getPixel(imagebit.getWidth()/2 - imagebit.getWidth() - 20,imagebit.getHeight()/2 - imageCarre.getHeight() / 4);
                        pixelRouge = Color.red(pixel);
                        pixelBleu = Color.blue(pixel);
                        pixelVert = Color.green(pixel);
                        tabCouleur[pos] = getColor(pixelRouge, pixelVert, pixelBleu);
                        break;
                    case 4:
                        pixel = imagebit.getPixel(imagebit.getWidth()/2 - imagebit.getWidth() / 4,imagebit.getHeight()/2 - imageCarre.getHeight() / 2);
                        pixelRouge = Color.red(pixel);
                        pixelBleu = Color.blue(pixel);
                        pixelVert = Color.green(pixel);
                        tabCouleur[pos] = getColor(pixelRouge, pixelVert, pixelBleu);
                        break;
                    case 5:
                        pixel = imagebit.getPixel(imagebit.getWidth()/2 - imagebit.getWidth() - 20,imagebit.getHeight()/2 - imageCarre.getHeight() / 2);
                        pixelRouge = Color.red(pixel);
                        pixelBleu = Color.blue(pixel);
                        pixelVert = Color.green(pixel);
                        tabCouleur[pos] = getColor(pixelRouge, pixelVert, pixelBleu);
                        break;
                    case 6:
                        pixel = imagebit.getPixel(imagebit.getWidth()/2 - imagebit.getWidth() / 4,imagebit.getHeight()/2 - imageCarre.getHeight() - 20);
                        pixelRouge = Color.red(pixel);
                        pixelBleu = Color.blue(pixel);
                        pixelVert = Color.green(pixel);
                        tabCouleur[pos] = getColor(pixelRouge, pixelVert, pixelBleu);
                        break;
                    case 7:
                        pixel = imagebit.getPixel(imagebit.getWidth()/2 - imagebit.getWidth() / 2,imagebit.getHeight()/2 - imageCarre.getHeight() - 20);
                        pixelRouge = Color.red(pixel);
                        pixelBleu = Color.blue(pixel);
                        pixelVert = Color.green(pixel);
                        tabCouleur[pos]  = getColor(pixelRouge, pixelVert, pixelBleu);
                        break;
                    case 8:
                        pixel = imagebit.getPixel(imagebit.getWidth()/2 - imagebit.getWidth() - 20,imagebit.getHeight()/2 - imageCarre.getHeight() - 20);
                        pixelRouge = Color.red(pixel);
                        pixelBleu = Color.blue(pixel);
                        pixelVert = Color.green(pixel);
                        tabCouleur[pos] = getColor(pixelRouge, pixelVert, pixelBleu);
                        break;
                    default:
                        break;
                }
            }
            listFaceCube.add(new FaceDuCube(tabCouleur));
        }
        return listFaceCube;
    }





    /*public void AfficherImage(View v){

        switch (v.getId()){
            case R.id.Face1 :
                imgBtn1.setImageBitmap(image);

                mCamera.startPreview();
                break;
            case R.id.Face2:
                imgBtn2.setImageBitmap(image);
                break;
            case R.id.Face3:
                imgBtn3.setImageBitmap(image);
                break;
            case R.id.Face4:
                imgBtn4.setImageBitmap(image);
                break;
            case R.id.Face5:
                imgBtn5.setImageBitmap(image);
                break;
            case R.id.Face6:
                imgBtn6.setImageBitmap(image);
        }
    }
*/
    public void AfficherImage(View v){
        switch (v.getId()){
            case R.id.Face1 :
                    imgBtn1.setImageBitmap(image);
                    ChercherCouleur(image);
                    listeimage.add(0,image);
                    mCamera.startPreview();
                    break;

            case R.id.Face2:

                    imgBtn2.setImageBitmap(image);
                    ChercherCouleur(image);
                    listeimage.add(1,image);
                    mCamera.startPreview();
                    break;


            case R.id.Face3:

                    imgBtn3.setImageBitmap(image);
                    ChercherCouleur(image);
                    listeimage.add(2,image);
                    mCamera.startPreview();

                    break;


            case R.id.Face4:

                    imgBtn4.setImageBitmap(image);
                    ChercherCouleur(image);
                    listeimage.add(3,image);
                    mCamera.startPreview();
                    break;

            case R.id.Face5:

                    imgBtn5.setImageBitmap(image);
                    ChercherCouleur(image);
                    listeimage.add(4,image);
                    mCamera.startPreview();
                    break;

            case R.id.Face6:

                    imgBtn6.setImageBitmap(image);
                    ChercherCouleur(image);
                    listeimage.add(5,image);
                    mCamera.startPreview();
                    break;


        }
    }
    public static void saveToPreferences(Context context, String key,
                                         Boolean allowed) {
        SharedPreferences myPrefs = context.getSharedPreferences
                (CAMERA_PREF, Context.MODE_PRIVATE);
        SharedPreferences.Editor prefsEditor = myPrefs.edit();
        prefsEditor.putBoolean(key, allowed);
        prefsEditor.commit();
    }


    private File getfile(){
        File dossier = new File("sdcard/camera_app");

        if(!dossier.exists()){
            dossier.mkdir();
        }
        File image_dossier = new File(dossier,"cam_image.jpg");
        return image_dossier;
    }




    private void showSettingsAlert() {
        AlertDialog alertDialog = new AlertDialog.Builder(this).create();
        alertDialog.setTitle("Alert");
        alertDialog.setMessage("L'application a besoins de la Camera pour foncitonner");
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Ne pas Autoriser",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        //finish();
                    }
                });}

    private void showAlert() {
        AlertDialog alertDialog = new AlertDialog.Builder(this).create();
        alertDialog.setTitle("Alert");
        alertDialog.setMessage("L'application a besoins de la Camera.");
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Ne pas Autoriser",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        finish();
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Autoriser",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        ActivityCompat.requestPermissions(MainActivity.this,
                                new String[]{Manifest.permission.CAMERA},
                                REQUEST_CAMERA);

                    }
                });
        alertDialog.show();
    }
    public static Boolean getFromPref(Context context, String key) {
        SharedPreferences myPrefs = context.getSharedPreferences
                (CAMERA_PREF, Context.MODE_PRIVATE);
        return (myPrefs.getBoolean(key, false));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        /*if(requestCode==REQUEST_CAMERA){
            if(grantResults[0]==PackageManager.PERMISSION_GRANTED){
                invoquerCamera();
            }
            else{
                Toast.makeText(this,getString(R.string.unable_revoque_camera),Toast.LENGTH_LONG).show();
            }
        }
        */
        switch (requestCode) {
            case REQUEST_CAMERA: {
                for (int i = 0, len = permissions.length; i < len; i++) {
                    String permission = permissions[i];
                    if (grantResults[i] == PackageManager.PERMISSION_DENIED) {
                        boolean showRationale =
                                ActivityCompat.shouldShowRequestPermissionRationale
                                        (this, permission);
                        if (showRationale) {
                            showAlert();
                        } else if (!showRationale) {
                            saveToPreferences(MainActivity.this, ALLOW_KEY, true);
                        }
                    }
                }
            }
        }
    }

    private String saveToInternalSorage(Bitmap bitmapImage){
        ContextWrapper cw = new ContextWrapper(getApplicationContext());
        // path to /data/data/yourapp/app_data/imageDir
        File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);
        // Create imageDir
        File mypath=new File(directory,"marina1.jpg");

        FileOutputStream fos = null;
        try {

            fos = new FileOutputStream(mypath);

            // Use the compress method on the BitMap object to write image to the OutputStream
            bitmapImage.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return directory.getAbsolutePath();
    }


}
