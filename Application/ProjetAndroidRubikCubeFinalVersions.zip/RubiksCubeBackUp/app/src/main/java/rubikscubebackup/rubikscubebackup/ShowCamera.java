package rubikscubebackup.rubikscubebackup;

import android.content.Context;
import android.content.res.Configuration;
import android.hardware.Camera;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.hardware.Camera.AutoFocusCallback;
import android.widget.Toast;

import java.io.IOException;
import java.lang.reflect.Parameter;
import java.util.List;

import static android.content.ContentValues.TAG;

public class ShowCamera extends SurfaceView implements SurfaceHolder.Callback,AutoFocusCallback{
    android.hardware.Camera camera;
    SurfaceHolder holder;
    Camera.AutoFocusCallback autoFocusCallback = new AutoFocusCallback() {
        @Override
        public void onAutoFocus(boolean b, Camera camera) {

        }
    };

    public ShowCamera(Context context, android.hardware.Camera camera){
        super(context);
        this.camera = camera;
        holder = getHolder();
        holder.addCallback(this);

    }


    @Override
    public void surfaceCreated(SurfaceHolder surfaceHolder) {
        android.hardware.Camera.Parameters params = camera.getParameters();
        String focus_mode;
        if(this.getResources().getConfiguration().orientation != Configuration.ORIENTATION_LANDSCAPE){
            params.set("orientation","portrait");
            camera.setDisplayOrientation(90);
            params.setRotation(90);
        }
        else{
            params.set("orientation","landscape");
            camera.setDisplayOrientation(0);
            params.setRotation(0);
        }
        focus_mode = params.getFocusMode();
        params.setFocusMode(focus_mode);
        List<Camera.Size> sizes = params.getSupportedPictureSizes();
        android.hardware.Camera.Size mSize = null;
        for(android.hardware.Camera.Size size : sizes){
            mSize = size;
        }

        params.setPictureSize(mSize.width,mSize.height);
        camera.setParameters(params);
        try{
            camera.setPreviewDisplay(holder);
            camera.startPreview();
        }
        catch (IOException e){
            e.printStackTrace();
        }
    }

    @Override
    public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i1, int i2) {
        camera.autoFocus(autoFocusCallback);
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        camera.stopPreview();
        camera.release();
    }

    @Override
    public void onAutoFocus(boolean b, Camera camera) {

    }
}
